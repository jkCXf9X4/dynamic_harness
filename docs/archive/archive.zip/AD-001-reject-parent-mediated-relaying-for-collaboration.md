---
id: AD-001
title: Reject Parent-Mediated Relaying for Collaboration
summary: The parent introduces and oversees collaboration but never relays child-to-child content.
date: 2026-09-22
status: accepted
layers: [architecture]
state: 06-evolution/investigations/multi-agent-coordination/scope-options.md
artifacts:
  - product-breakdown/02-architecture/multi-agent-coordination/
  - scope-options.md
  - requirements-group.md
  - channel-decision.md design leaves
  - product-breakdown/04-verification/communication-structures/ (INVESTIGATION, PLAN, FINDINGS, RESULTS, metrics-cells.json, context-injection-design.md)
  - src/dynamic_harness/core/comms/ (the swappable comms layer, AD-008)
supersedes: []
superseded_by: []
related: [AD-002, AD-003, AD-008]
---

# AD-001: Reject Parent-Mediated Relaying for Collaboration

## Context
Moving from *complicated* development (parallel decomposition into independent
sub-parts) toward *complex* development (a parent stands up children that
communicate and solve together) requires choosing a collaboration topology.
Option A — parent-mediated relaying, all child↔child interaction relayed through
the parent via `stream_children` + `converse` — best fit the actor model but was
rejected. Documented in `multi-agent-coordination/scope-options.md` (option A +
"Why rejected") and empirically confirmed by
`04-verification/communication-structures/FINDINGS.md` + `RESULTS.md` (real-LLM
benchmark, 2026-09-18, deepseek-v4-flash). The rejection rationale and deadlock
evidence are DOCUMENTED; only the claim that these are what the missing
decision-log entry "would have said" is INFERRED.

## Decision
Parent-mediated relaying (option A) is **rejected**. The parent must not relay
child↔child content. Collaboration uses a topic-channel / workspace-primary
communication layer with bounded message exceptions (AD-002, AD-003): the parent
*introduces* and *oversees* but never *relays*.

## Rationale
A parent that relays every child↔child exchange becomes the coordination bottleneck: it must hold both sides' context, its settlement stream grows with team size, and circular "wait on each other" calls deadlock (P4 `off` cell: 0 turns, 900s watchdog). The actor-model fit of option A was outweighed by the measured failure and unbounded context pollution; a scoped channel keeps most traffic off the parent.

## Alternatives Considered
- **A. Stay parent-mediated (enhance `stream_children` + `converse`)** — REJECTED.
- **B. Sibling mailbox** — direct peer-to-peer messaging; adopted in curated
  form (B-curated: common-parent scoping, AD-002).
- **C. Team/panel (bounded shared workspace + chair)** — adopted as the
  workspace substrate in the hybrid channel decision (AD-003).

## Consequences
**Positive:** the orchestrating parent does not degrade into a monolithic agent
as coordination grows; no mixed-context pollution from child settlements and
converse replies crossing branches; empirically validated — the relay-style
`off` cell **deadlocked** on circular blocking `converse` calls (0 turns, 900s
watchdog) while the `shared` channel cell completed correctly (40 turns / 389s;
FINDINGS.md "Deadlock: circular converse blocks the whole tree — CONFIRMED").

**Negative:** relaxing actor-model isolation in a bounded, curated way (AD-002);
new A↔B↔A churn/looping surface needs per-pair cycle detection (REQ-9); the
runtime must track sibling edges alongside parent→child edges.

## Verification
Real-LLM benchmark (P4, 2026-09-18): relay-style `off` cell deadlocked
(timed_out, 0 turns, 900s); `shared` channel cell completed correctly (40 turns,
389s, ~0.8M tokens) — FINDINGS.md + RESULTS.md + metrics-cells.json.
Re-verification pending: more replicates (n=1 per cell today) — see IMP-001.

## Review Trigger
Revisit if a bounded, lock-safe `converse` (bounded wait for the target's next
assistant message instead of its whole re-run) removes the deadlock mechanism,
or if a topology measurement shows parent-relay beating channel topologies on
cost/quality at scale.
