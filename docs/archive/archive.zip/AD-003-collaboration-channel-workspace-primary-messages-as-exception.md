---
id: AD-003
title: Collaboration Channel = Workspace-Primary, Messages-as-Exception
summary: Collaboration runs on a shared scoped workspace as the primary channel, with peer messages as the scarce exception for equivocal coordination.
date: 2026-09-22
status: accepted
layers: [architecture]
state: 06-evolution/investigations/multi-agent-coordination/channel-decision.md
artifacts:
  - product-breakdown/02-architecture/multi-agent-coordination/channel-decision.md
  - requirements-steering.md
  - collaboration-setting/behavioral-rules.md
  - product-breakdown/04-verification/communication-structures/context-injection-design.md
  - src/dynamic_harness/core/comms/
  - core/tools/comms.py
supersedes: []
superseded_by: []
related: [AD-002, AD-001]
---

# AD-003: Collaboration Channel = Workspace-Primary, Messages-as-Exception

## Context
With the group defined (AD-002), the remaining choice is the **collaboration
channel**: peer *messages* (B-curated) or a shared *workspace* (C)? Four theories
anchor it: media richness (Daft & Lengel), boundary objects (Star & Griesemer),
blackboard/distributed AI (Hearsay-II), and collaborative engineering practice
(git / PR / code review). Documented in `multi-agent-coordination/channel-decision.md`
and `management-theory/`; rationale basis DOCUMENTED (decision + four rules
stated explicitly, anchored in the cited theories).

## Decision
The collaboration channel is a **shared, scoped workspace** (a sibling-visible
artifact area) as the primary substrate; **peer messages are the scarce, bounded
exception** used only for *equivocal* coordination. Decision rules:
1. **Share a result, finding, or constraint → write/read the workspace.** The
   artifact is the boundary object; "coordination without consensus" applies.
2. **Route or ask "who knows this?" → a message that points to the workspace**
   (ID + why), not a payload (mirrors REQ-4). TMS retrieval.
3. **Reconcile conflicting interpretations / demand a revision → messages**, the
   rich channel, bounded per-pair and hard-stopped on over-budget (REQ-6, REQ-9)
   when the exchange should escalate to the parent or a fresh worker.
4. **Default source of truth is the workspace.** If a child that read the
   artifact disagrees with a sibling's message, the artifact wins; escalate if
   it matters (REQ-12, existing VERIFY).

## Rationale
Most collaboration shares results, findings, and constraints — boundary objects the recipient reads on demand (pull), not content pushed into its context. Rich messages are only needed for equivocal exchanges, so they are the scarce, bounded exception: interruptiveness is the cost that must stay rare.

## Alternatives Considered
- **B-curated pure (peer messages as the channel)** — REJECTED as primary:
  pre-stabilization direct negotiation is "frustrating" and escalates friction
  (boundary-objects literature); messages are interruptive (push).
- **C pure (shared workspace only, no messages)** — REJECTED as sole channel:
  equivocal coordination needs rich media with fast feedback; too-lean media for
  equivocal tasks causes more difficulties than too-rich media for lean tasks.
- **A (parent-mediated relaying)** — REJECTED (AD-001).

## Consequences
**Positive:** the parent relays nothing; recipient context is protected because
most coordination is *pull* (read what you need) not *push*; churn/loop risk
shrinks (the bounded message channel sees only equivocal exchanges); anchored in
practice (git-team coordination, blackboard architectures).

**Negative:** workspace mechanics are undefined (a scoped `ArtifactStore` area
needs write-conflict + visibility rules the store does not enforce) — IMP-002;
cadence/round semantics are undefined ("which children wait on a sibling's
write") — IMP-002; equivocality is judged by the model and needs a stated
heuristic (bias workspace-first) — IMP-003.

## Verification
Comms benchmark: the `shared` cell completed the interdependent collab task
correctly in 40 turns / 389s / ~0.8M tokens (FINDINGS.md reading 2);
`tests/backend/test_comms.py` + `test_comms_benchmark.py`. Pending: workspace
mechanics (IMP-002) and equivocality heuristic (IMP-003).

## Review Trigger
Revisit if the workspace-primary rule proves wrong for a measured pattern (e.g.
message-mediated negotiation dominates), or if IMP-003 shows the model cannot
reliably distinguish equivocal vs uncertain coordination.
