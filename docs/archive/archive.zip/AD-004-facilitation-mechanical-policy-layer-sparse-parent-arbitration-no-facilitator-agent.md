---
id: AD-004
title: Facilitation = Mechanical Policy Layer + Sparse Parent Arbitration, No Facilitator Agent
summary: Facilitation is a three-layer stack of pure peer-to-peer, mechanical policy, and sparse parent arbitration, with no facilitator agent.
date: 2026-09-22
status: accepted
layers: [architecture]
state: 06-evolution/investigations/multi-agent-coordination/facilitation-layer.md
artifacts:
  - product-breakdown/02-architecture/multi-agent-coordination/facilitation-layer.md
  - collaboration-setting/behavioral-rules.md
  - src/dynamic_harness/core/comms/digest.py
  - core/comms/channel.py
  - core/policies/ (REQ-6)
supersedes: []
superseded_by: []
related: []
---

# AD-004: Facilitation = Mechanical Policy Layer + Sparse Parent Arbitration, No Facilitator Agent

## Context
Should the collaboration channel have a **facilitator**, or stay **pure
child-to-child**? Theory resolves this as a three-layer stack where the
"facilitator" is almost entirely *mechanical structure*, with *sparse*
arbitration only at conflict. The anchor is Elinor Ostrom's commons governance
(Nobel 2009, *Governing the Commons*, 1990): long-lived shared-resource groups
thrive through explicit institutional design — mechanisms, not a person.
Documented in `facilitation-layer.md` + `management-theory/` (Doyle et al.).

## Decision
Facilitation is a **three-layer stack with no facilitator agent**:
- **L0 — Pure peer-to-peer (steady state).** Workspace reads/writes + bounded
  message channel, direct child↔child, parent absent; the "context over control"
  default.
- **L1 — Mechanical facilitation (the invisible facilitator).** All policy/code,
  zero LLM tokens, no bottleneck: boundaries/membership (REQ-1/2, Ostrom #1);
  monitoring via append-only writes + provenance (Ostrom #4, "monitors are the
  users"); graduated sanctions (REQ-6 caps, REQ-9 loop detection — warn →
  tighten → hard stop → notify, Ostrom #5); round/cadence; write-conflict.
- **L2 — Sparse arbitration (the low-cost local arena).** The only *agent*
  facilitation, for conflicts L0/L1 cannot resolve: children negotiate over the
  rich channel first; an *unresolved* dispute escalates once to the **parent**,
  who arbitrates once and is done (arbitrate, converse, disconnect, dissolve).
  Ostrom #6 + Netflix "step in at risk points" + Hackman coaching (REQ-8/14).

## Rationale
Ostrom's commons governance shows long-lived shared-resource groups need institutional structure — monitoring, sanctions, conflict resolution — not a person. A facilitator agent duplicates policy, spends tokens, and becomes a point of failure; making the facilitation mechanical (L1) and the arbitration sparse (parent only at conflict) delivers governance at ~zero token cost.

## Alternatives Considered
- **Pure child-to-child with zero facilitation** — REJECTED: the commons-tragedy
  trap (no monitoring, sanctions, or conflict resolution).
- **An always-on facilitator agent** — REJECTED: repeats option A's cost model,
  duplicates policy, violates content-neutrality, becomes a point of failure.
- **A facilitator agent for very large groups (edge case)** — NOT default: a
  content-neutral sibling "chair" is defensible only when the parent is
  saturated; scoped to L2 and parent-overridable.

## Consequences
**Positive:** self-governance without a boss (Ostrom's principles as code, not
a person); zero-token facilitation (L1 is policy); low-cost local conflict
resolution (one escalation to the parent, who holds authority); REQ-13/14/15.

**Negative:** the parent is awakened for risk-point events (new connection,
over-budget, escalation, child lacking context — REQ-8); if it later reads
exchange *content* to "help", it decays into rejected option A (content is
pull-only, oversight is one event line); L1's rules must be specified as policy
objects — workspace mechanics and cadence are still open (IMP-002).

## Verification
`topics_parent` (parent-authorized creation — the L2 authority model) completed
correctly in P4, with ~6× churn vs `shared` (topic-policing/polling; n=1 —
IMP-001). Tests: `tests/backend/test_comms.py`. Pending: IMP-002 (L1 executable).

## Review Trigger
Revisit if the sparse-arbitration model fails (conflicts unresolved at L0/L1,
parent arbitration serializing), or a very large group makes the L2 chair worth it.
