---
id: AD-006
title: Spine = Runtime `_links` + Reuse of Converse/_inject_queue + Artifact/Result Pointers; Spec Demoted to Advanced Policy Layer
summary: The collaboration core is a three-primitive spine of links, reused converse delivery, and artifact pointers, with the spec demoted to policy.
date: 2026-09-22
status: accepted
layers: [architecture]
state: 06-evolution/investigations/multi-agent-coordination/spine.md
artifacts:
  - product-breakdown/02-architecture/multi-agent-coordination/spine.md
  - collaboration-setting/README.md
  - src/dynamic_harness/core/policies/links.py (proposed — the tiny new file)
  - src/dynamic_harness/core/agent.py
  - core/comms/ (converse eligibility gate)
supersedes: []
superseded_by: []
related: []
---

# AD-006: Spine = Runtime `_links` + Reuse of Converse/_inject_queue + Artifact/Result Pointers; Spec Demoted to Advanced Policy Layer

## Context
The collaboration-setting spec over-modeled. The advanced features (team
object, charter, norms, sanctions, workspace, arbitration ladder) are policy
layers on a much smaller spine — and the spine is mostly *existing machinery*.
A simplicity review distilled it to three primitives, all present today.
Documented in `spine.md` + `collaboration-setting/README.md`.

## Decision
The architecture is a **three-primitive spine**; the spec is **demoted to the
advanced policy layer** (AC-1..11 still hold, as *policy-layer* acceptance):
1. **Links** — ONE new structure: a runtime registry of authorized peer pairs
   (`self._links: set[tuple[str, str]]`, unordered, normalized). The *only*
   rule: `link(a, b)` is accepted iff the caller is the common parent of both
   (`a.parent is caller and b.parent is caller`): membership *is* the link set.
2. **Delivery** — reuse the existing message path: `converse` →
   `continue_with_input` → `_inject_queue`/`_inject_event`. A sibling message is
   a `converse` whose eligibility gate becomes `(agent_a, agent_b) in
   self._links` (plus parent↔child). Summary-only, pointer-carrying:
   `[sibling {id}] {summary}\nPointer: {artifact_id|result_id}`.
3. **Content** — reuse existing pointer machinery: the recipient pulls the body
   via `read_artifact` / `result_read`. **No workspace needed for MVP**: shared
   immutable display-scoped state; the missing piece was *discovery*.

Lifecycle is free: `link` edges die when the parent settles (deleting the
subtree), or via `disconnect(a, b)`; no disband ceremony needed.

## Rationale
The collaboration-setting spec over-modeled. Three primitives — a link registry, the existing converse/_inject_queue delivery, artifact/result pointers — cover the MVP, and the rest is policy layered on top. Reusing existing machinery instead of a new TeamMailbox/workspace is hours vs days and shrinks the enforcement surface to one eligibility check.

## Alternatives Considered
- **The full spec as core** (Team object, `TeamStatus` FSM, membership dict,
  charter, workspace scoping, sanctions records) — REJECTED: days vs hours; the
  advanced processes compose on the spine (streaming, all-pairs broadcast,
  per-link counters, MAC catalogue, mechanical verify, L2, nested, resume).
- **A new TeamMailbox / scoped workspace dir as core** — REJECTED for MVP:
  `_inject_queue` and ArtifactStore/ResultStore + pointers already provide
  delivery and shared state; the missing piece was discovery only.

## Consequences
**Positive:** enforcement shrinks to link registry + an eligibility check in one
place (converse path) + a counter; time to value is hours, not days (new file
`policies/links.py`, tiny); composes with advanced processes (broadcast = O(n²)
macro; mechanical verify = a policy inspecting pointer targets at settlement);
resume/recovery is free (links reference agent ids).

**Negative:** the advanced layer (workspace mechanics, cadence, sanctions UI) is
deferred — AC-1..11 are not yet executable (IMP-002/003/004); the spine's
summary-only delivery assumes the recipient pulls content — a pattern needing
push of full content is not covered by the MVP.

## Verification
The spine's delivery path (converse/_inject_queue) is already exercised by the
shipped `converse` tool and the comms layer; the P4 benchmark ran the channel
topologies on it (RESULTS.md). Pending: `_links` + eligibility gate (designed).

## Review Trigger
Revisit if the spine's summary-only delivery proves insufficient (recipients
need pushed content), or if the advanced layer's deferred features prove core.
