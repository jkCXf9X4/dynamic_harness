---
id: AD-002
title: Collaboration Group = Children of a Common Parent, Explicit Membership, Default-Deny
date: 2026-09-22
status: accepted
layers: [architecture]
state: 06-evolution/investigations/multi-agent-coordination/requirements-group.md
artifacts:
  - product-breakdown/02-architecture/multi-agent-coordination/sibling-collaboration.md
  - requirements-group.md
  - "src/dynamic_harness/core/comms/backends/siblings.py (cell 2: same-parent scope)"
  - src/dynamic_harness/core/comms/channel.py
  - core/tools/comms.py (ChannelPolicy)
supersedes: []
superseded_by: []
related: [AD-001, AD-003]
---

# AD-002: Collaboration Group = Children of a Common Parent, Explicit Membership, Default-Deny

## Context
Enabling peer collaboration (option B) violates the actor-model
context-encapsulation invariant ("know only parent + children + task"), so the
group must be bounded and authorized. The runtime already tracks parentage
(`task.parent_id`, the task graph), so "children of one parent" needs zero new
structural entities. Documented in
`multi-agent-coordination/sibling-collaboration.md` (deep dive B) and
`requirements-group.md` (REQ-1/2); the advanced spec is
`collaboration-setting/purpose-and-scope.md`. Rationale basis: DOCUMENTED —
REQ-1/REQ-2 state the theory citations (Hackman: real team; Project Aristotle:
structure & clarity; TMS directory; bounded rationality).

## Decision
A collaboration group is **children of a common parent, with explicit
membership** (REQ-1). Peer messaging is **default-deny**: a pair may communicate
only if the parent introduced it — at delegation via `collaborate_with=[...]`, or
mid-run via `introduce(agent_a, agent_b, note)` (REQ-2). The permission is an
*edge*, not a global right, enforced in `get_other_agent` / a policy object. The
parent is the group's authority: it can authorize, observe, and revoke channels.

## Rationale
Peer collaboration violates the "know only parent + children + task" isolation invariant, so the relaxation must be bounded and revocable. Restricting groups to children of one common parent collapses the permission problem to "same parent" — zero new structural entities — and confines cross-branch contamination to a trusted set the parent can observe and revoke.

## Alternatives Considered
- **Unconstrained B (any agent may message any agent)** — REJECTED: re-opens
  unbounded cross-branch contamination and needs a global permission system.
- **A (parent-mediated relaying)** — REJECTED (AD-001): parent becomes a
  bottleneck and its context rots.
- **C (team/panel with chair)** — converges with B-curated once introductions
  exist; the channel decision (AD-003) picks the hybrid.

## Consequences
**Positive:** contamination is confined to a trusted sibling set sharing a
coordinator (no global graph addressing); no new permission subsystem (scope
collapses to "same parent"); cycles are bounded to a small known edge set, so
per-pair counters make loop detection tractable (REQ-9); introductions are
requestable and declinable with no penalty (REQ-3).

**Negative:** the isolation invariant is softened for the group (mitigated by
summary-only delivery, per-recipient caps, and the parent's final VERIFY);
adverse sibling data is possible — a sibling message is input, not authority
(REQ-12); channels close when the parent settles/is killed and settled siblings
are read-only targets (REQ-10).

## Verification
Comms benchmark cell 2 (`siblings`) exercises the same-parent scope rule; the
`topics_parent` cell completed correctly in the P4 real-LLM run (232 turns) — see
`04-verification/communication-structures/RESULTS.md`. Unit tests:
`tests/backend/test_comms.py`. Pending: workspace mechanics + cadence (IMP-002)
and `introduce` (IMP-004).

## Review Trigger
Revisit if a topology measurement shows the parent-authorized channel set
(`topics_parent`) is too costly (P4 showed ~6× churn vs `shared`; hypothesis:
topic-policing/polling overhead; needs replicates, IMP-001), or if default-deny
proves too restrictive for a real pattern.
