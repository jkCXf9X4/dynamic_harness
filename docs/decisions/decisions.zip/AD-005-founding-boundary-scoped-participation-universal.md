---
id: AD-005
title: Founding Boundary-Scoped, Participation Universal
date: 2026-09-22
status: accepted
layers: [architecture]
state: 06-evolution/investigations/multi-agent-coordination/collaboration-setting-model.md
artifacts:
  - product-breakdown/02-architecture/multi-agent-coordination/capability-scope.md
  - collaboration-setting-model.md
  - src/dynamic_harness/core/agent.py (CollaborationCapability mixin/interface)
  - src/dynamic_harness/core/comms/channel.py (ChannelPolicy — delegation boundary)
supersedes: []
superseded_by: []
related: [AD-001]
---

# AD-005: Founding Boundary-Scoped, Participation Universal

## Context
Is layer-by-layer collaboration an *orchestration* feature (only orchestrators
may form teams) or a *general capability every agent possesses*? Hackman's five
conditions (#1 real team, #2 compelling direction) and Ostrom's #8 (nested
enterprises) are the ground. Documented in `capability-scope.md` +
`collaboration-setting-model.md` with Hackman/Ostrom citations.

## Decision
The capability splits along the two halves the theory separates — **leader sets
conditions, members execute** (Hackman) and **mechanisms are institutions, not
persons** (Ostrom):
- **Founding is boundary-scoped.** Any **node with children** may found a team:
  declare membership (`collaborate_with` / `introduce`), post the team charter
  (direction + acceptance), open the team workspace, arbitrate conflicts. Only
  the parent has the decomposition view and authority to bound membership; a
  leaf cannot found a team it cannot see.
- **Participation is universal.** **Every agent, at any depth, leaves
  included**, may act as a team member: read/write the team workspace, bounded
  messages, negotiate, escalate. Interdependence is not depth-dependent; two
  leaf siblings holding half a result are exactly a Hackman "real team".

Codified as one `CollaborationCapability` object on every `Agent` with two
facets — MEMBER (active iff a parent introduced you) and FOUNDER (active iff you
have children) — where **activation is structural, not role-based**: no class
split, no role string, nothing to promote. Nested enterprises compose by
construction.

## Rationale
Interdependence is not an orchestration privilege: two sibling leaves holding half a result are a Hackman "real team". Founding needs the boundary view only a parent has, so it is scoped to nodes with children, while participation stays universal — activation is structural (having children / being introduced), never role-based.

## Alternatives Considered
- **Orchestration-only** — REJECTED: interdependence is not depth-dependent;
  forcing every collaborating leaf to delegate grows the tree (against "flat, shallow trees").
- **General founding (any agent may introduce arbitrary others)** — REJECTED:
  needs global addressing/authority — the unconstrained-B shape (AD-001/002).
- **Role-tag-based activation** — REJECTED: founding self-restricts to nodes
  that *have* children (`self.children`), cleaner and scales with delegation.

## Consequences
**Positive:** collaboration scales with delegation by construction (a subtree
that spawns interdependent children gets a team; independent fan-out needs
none); leaves that hand off via the team workspace stay leaves, so trees stay
shallow; nested enterprises (Ostrom #8) compose — a node is a member of its
parent's team and, if it has children, founder of its own; the object is inert
until structure activates it, so distribution ≠ privilege.

**Negative:** the founding decision still lives at each boundary — uniform
machinery changes *where the code lives*, not *who decides membership* (not
fully self-organizing); the collaboration setting must be instantiated per
layer — workspace mechanics and cadence are still open (IMP-002).

## Verification
The `topics_parent` cell (parent-authorized creation at the delegation boundary)
completed correctly in P4 — boundary-scoped founding end-to-end. Tests:
`tests/backend/test_comms.py` (may_create / may_join). Pending: `introduce` (IMP-004).

## Review Trigger
Revisit if a measured pattern shows leaves needing to found teams (boundary-
scoped founding too restrictive), or if structural activation proves unclear.
