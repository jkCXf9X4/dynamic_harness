---
id: AD-007
title: Plugin Direction = Interface Economy (~7 Seams), No Loader / Late Injection
date: 2026-09-22
status: accepted
layers: [implementation]
state: 06-evolution/investigations/plugin/investigation/README.md
artifacts:
  - product-breakdown/03-implementation/plugin/investigation/README.md
  - src/dynamic_harness/core/tools/
  - core/policies/
  - core/events.py
  - src/dynamic_harness/llm/provider.py
  - core/runtime.py
  - core/task.py
  - artifact/store.py
  - memory/repository.py
supersedes: []
superseded_by: []
related: []
---

# AD-007: Plugin Direction = Interface Economy (~7 Seams), No Loader / Late Injection

## Context
The harness is a monolith of *near-seams*: tools by concern, host-agnostic
policy objects, a metric-reactive registry that calls itself "the plugin seam",
an event bus, an LLM provider ABC. Each is individually extensible in code, but
the seams are *incidental* — shapes differ, breadth varies, components reach
across them. The seed asked for a common metric-reactive policy interface to
"facilitate the move towards a more plugin centric architecture"; documented in
`03-implementation/plugin/investigation/README.md` (Q1–Q7) and the backlog.

## Decision
Make the codebase plugin-*ready* by establishing a **small, stable set of ~7
narrow common interfaces** and decoupling components behind them — **without** a
plugin architecture (no loader, late injection, manifest, scanning, entry points):
1. Tool call contract — `ToolDef` / `ToolResult` / `ToolContext` + `ToolRegistry`
2. Metric-reactive policy — `Observation` / `PromptInjection` / `ReactivePolicy` / `ReactivePolicyRegistry`
3. Decision-policy objects (host-agnostic, import no agent/runtime)
4. Event bus — `EventBus` + event payload types
5. LLM provider — `LLMProvider` ABC + response/call types
6. Agent-class registry — `register_agent_class` / `delegate(agent_type=)`
7. Persistent data types — `Task` / `ReportPayload` / `Artifact` / `Commit` / `AgentOutcome`

Supporting rulings: Q1 internal-structure enabler; Q3 crash loudly, never
swallow a broken component; Q4 safety frozen (policies replaceable, tools/agent
classes additive); Q5 code-only config; Q6 no stdlib descriptor conversion; Q7
no discovery, ever. `ToolContext` stays ONE contract, narrowed (faceting rejected).

## Rationale
The codebase is a monolith of incidental near-seams; a loader (late injection, discovery) buys nothing until the seams are minimal and stable. A small fixed set of ~7 narrow contracts decouples components with no plugin machinery, making replaceability a side effect of structure rather than of runtime indirection.

## Alternatives Considered
- **A. Loader / late-injection plugin architecture** — REJECTED (OUT OF SCOPE):
  "a loader buys nothing until the seams are already minimal"; plugin-ready
  *structure* is the target (a loader could sit on top much later).
- **C. Two-worlds (internal seams + external transport)** — REJECTED (OUT OF
  SCOPE): an MCP/third-party host belongs to `00-intent/platform-evaluation/README.md`.
- **Faceted ToolContext** — REJECTED: faceting multiplies the interface count.

## Consequences
**Positive:** replaceability becomes a side effect of narrow seams (swapping a
tool, policy, handler, or provider is a one-call act — no loader, no
monkey-patching); low risk (a refactor guarded by existing tests); pilot seam
IMPLEMENTED (compress prompt moved into `ContextMetricPolicy.COMPRESS_PROMPT`,
public `Agent.record_archived_artifact` / `Agent.usage_summary` replace private
reach, dead `ToolContext.message_count` removed; `pytest` green, 466 passed).

**Negative:** slower to see a "capability" land (structural work, not features);
requires discipline to avoid churning interfaces; the ~7 count must be held
stable while couplings are removed — narrow or trade shapes, never add contracts.

## Verification
Success criteria (INVESTIGATION §Success criteria): (1) count holds ≈7; (2) no
outside private-state reach (`rg "\._agent\b"` in `core/tools/` +
`core/tool_context.py`); (3) one canonical map; (4) zero dead surface; (5) zero
regressions (`pytest` green, 466 passed); (6) no loader, ever.

## Review Trigger
Revisit if the ~7 interface count grows (a new contract is needed), if a
measured coupling reappears, or if stable contracts make a loader worth
reconsidering (then it belongs to `00-intent/platform-evaluation/README.md`).
