---
id: AD-008
title: Comms Layer = Swappable Routing Backend Behind One Uniform Tool Surface
date: 2026-09-22
status: accepted
layers: [verification]
state: 06-evolution/investigations/communication-structures/README.md
artifacts:
  - product-breakdown/04-verification/communication-structures/ (INVESTIGATION, PLAN, FINDINGS, RESULTS, metrics-cells.json, context-injection-design.md)
  - src/dynamic_harness/core/comms/
  - core/tools/comms.py
  - benchmark/comms.py
  - resources/_collab
  - tests/backend/test_comms*.py +
supersedes: []
superseded_by: []
related: []
---

# AD-008: Comms Layer = Swappable Routing Backend Behind One Uniform Tool Surface

## Context
The verified baseline is **one implicit router**: `converse` reaches any agent
by ID (`get_other_agent` → `runtime.get_agent`), gated only by target status —
no parent-mediation gate, no sibling-scope gate, no mailbox, no topic registry.
The four topology cells (parent-mediated, same-parent siblings, one shared
channel, topic channels) cannot be toggled today; they must be *constructed*.
The comms work was measurement-first ("verification-led design"), documented in
`04-verification/communication-structures/` (INVESTIGATION, PLAN, design).

## Decision
Build a **thin, host-agnostic communication layer** between the tools and the
runtime so the four topology cells are a **config switch — not a refactor**. It
exposes **ONE uniform tool surface** (`converse` / `message` / `post` /
`channel_read` / `subscribe` / `unsubscribe` / `channels` / `channel_info`);
**only the routing backend differs per cell** (one config key or one
`Runtime(comms=...)` argument), mirroring `core/policies/` decision/execution.

Shape: `core/comms/` — `message.py` (CommsMessage), `backend.py` (CommsBackend:
route_message / post / subscribe / unsubscribe / read / channels / channel_info;
per-(agent, topic) watermarks, backend-owned), `channel.py` (ChannelPolicy),
`digest.py` (CommsDigestPolicy), `backends/` (relay, siblings, shared, topics),
`factory.py` (build_backend — the switching seam); tool defs in `core/tools/comms.py`.

## Rationale
The verified baseline is one implicit router the four topology cells cannot toggle. Measurement-first ("verification-led") design requires the cells to be constructible; a thin host-agnostic layer behind ONE uniform tool surface makes the topology a config switch — the cheapest construction that lets P4 gather real-LLM evidence before a topology is adopted.

## Alternatives Considered
- **One implicit router (status quo)** — REJECTED for the experiment: the four
  topologies cannot be toggled; a swappable layer is the cheapest construction.
- **Four separate tool surfaces (one per topology)** — REJECTED: the model would
  learn a new vocabulary per cell; the point is one vocabulary with the backend
  deciding who receives what.
- **Design reasoning alone (no measurement)** — REJECTED: success criterion 4 —
  "A topology (or the hybrid) is adopted on evidence, not on the dev
  investigation's design reasoning alone."

## Consequences
**Positive:** the tools an agent calls never change between cells; P0 (backends)
+ P1 (tool surface + config switching) + P2 (push-digest policy) + P3
(collaboration bed) are **implemented**; P4 (real-LLM, 2026-09-18) ran once —
`off` deadlocked (0 turns), `shared` completed correctly (40 turns / 389s /
~0.8M tokens), `topics_parent` completed with ~6× churn (232 turns / 5.2M
tokens / 765s); mock-first determinism makes the bed reproducible; the deadlock
mechanism is understood (blocking `converse` acquires the target's `_loop_lock`
and runs the whole re-run; channel topologies are robust).

**Negative:** P4 is n=1 per cell, pricing unconfigured (cost $0), interrupted
once by a kill — treat ratios, not absolutes, as signal (IMP-001); the
`topics_parent` churn hypothesis is untested; a lock-safe `converse` is out of scope.

## Verification
P0–P3: unit tests (`tests/backend/test_comms.py`, `test_comms_benchmark.py`) —
mock-LLM determinism. P4: real-LLM battery (2026-09-18, deepseek-v4-flash via
OpenRouter) — FINDINGS.md, RESULTS.md, metrics-cells.json. Pending: replicates.

## Review Trigger
Revisit if a replicate run (IMP-001) overturns the `shared`-wins reading, or if
a bounded/lock-safe `converse` changes the topology trade-offs.
